/**
 * Author - Kandarp Desai
 * CWID - 10419687
 * Date - 10/12/2017
 * Description - This method creates a rectangle class and 
 * 			   - Calculates area and perimeter of of the rectangle.
 * 			   - Checks if specified point lies inside original rectangle.
 *             - Checks if another rectangle lies inside original rectangle.
 *             - Checks if another rectangle overlaps original rectangle.     
 **/

public class C10E13MyRectangle2D {
	private double x,y;
	private double dHeight,dWidth;
	private String message;
	
	//Default constructor that creates rectangle with default values
	public C10E13MyRectangle2D() throws Exception {
		setX(0);
		setY(0);
		setdHeight(1);
		setdWidth(1);
	}
	//Parameterized constructor that creates rectangle with specified center,height and width.
	public C10E13MyRectangle2D(double x, double y, double dHeight, double dWidth) throws Exception {
		setX(x);
		setY(y);
		setdHeight(dHeight);
		setdWidth(dWidth);
	}

	public double getX() {
		return x;
	}
	public void setX(double x) {
		this.x = x;
	}
	public double getY() {
		return y;
	}
	public void setY(double y) {
		this.y = y;
	}
	public double getdHeight() {
		return dHeight;
	}
	public void setdHeight(double dHeight) throws Exception {
		if(! isValidHeight(dHeight)){
			message = "Error in input. The height of rectangle must be positive non-zero number ";
			Exception exception = new Exception(message);
			throw exception;
		}
		this.dHeight = dHeight;
	}
	public double getdWidth() {
		return dWidth;
	}
	public void setdWidth(double dWidth) throws Exception {
		if(! isValidWidth(dWidth)){
			message = "Error in input. The width of rectangle must be positive non-zero number";
			Exception exception = new Exception(message);
			throw exception;
		}
		this.dWidth = dWidth;
	}
	//This method checks if the height of rectangle is valid or not
	public boolean isValidHeight(double newHeight){
		if(newHeight > 0){
			return true;
		}
		else{
			return false;
		}
	}
	//This method checks if the width of rectangle is valid or not
	public boolean isValidWidth(double newWidth){
		
		if(newWidth > 0){
			return true;
		}
		else{
			return false;
		}
	}
	//This method calculates the area of rectangle
	public double getArea(){
		return (getdWidth()*getdHeight());
	}
	//This method calculates perimter of the rectangle
	public double getPerimeter(){
		double perimeter = 2 * (getdHeight() + getdWidth());
		return perimeter;	
	}
	//This method checks if a specified point lies inside the rectangle
	public boolean contains(double x, double y){
		
		return Math.abs(x-getX()) < getdWidth() / 2 && Math.abs(y-getY())< getdHeight() / 2;
		
	}
	// This method checks if specified rectangle is inside the original rectangle.
	public boolean contains(C10E13MyRectangle2D rectangle) {
		return contains(rectangle.getX() - rectangle.getdWidth() / 2, rectangle.getY() + rectangle.getdHeight() / 2) &&
			      contains(rectangle.getX() - rectangle.getdWidth() / 2, rectangle.getY() - rectangle.getdHeight() / 2) &&
			      contains(rectangle.getX() + rectangle.getdWidth() / 2, rectangle.getY() + rectangle.getdHeight() / 2) &&
			      contains(rectangle.getX() + rectangle.getdWidth() / 2, rectangle.getY() - rectangle.getdHeight() / 2);
	}
	// This method checks if the specified rectangle overlaps the original rectangle.
	public boolean overlaps(C10E13MyRectangle2D  rectangle1) {
		return Math.abs(getX() - rectangle1.getX()) <= (getdWidth() + rectangle1.getdWidth()) / 2 &&
			      Math.abs(getY() - rectangle1.getY()) <= (getdHeight() + rectangle1.getdHeight()) / 2;
	}

}
