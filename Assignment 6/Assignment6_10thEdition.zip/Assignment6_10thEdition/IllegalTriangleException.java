/**
 * Author - Kandarp Desai
 * CWID - 10419687
 * Date - 10/12/2017
 * Description - Exception class that raises exception if sum of two sides of triangle is less than third side
 */
public class IllegalTriangleException extends Exception{
	public IllegalTriangleException(String message) {
		super(message);
	}
}
