/**
 * Author - Kandarp Desai
 * CWID - 10419687
 * Date - 10/12/2017
 * Description - This program is a test program for C10E13MyRectangle2D class. It takes input from user calls appropriate 
 * 				 methods and displays the output to the user 
 **/

import javax.swing.JOptionPane;

public class C10E13MyRectangle2DTest {
		public static void main(String[] args) {
			boolean repeat = true;
			JOptionPane.showMessageDialog(null, "This program :\n 1. Displays the area and perimeter of the given rectangle.\n "
					+"2. Verifies whether given point lies inside the given rectangle.\n"
					+" 3. Verifies whether a specified rectangle is inside the given rectangle.\n"
					+" 4. Verifies whether a specified rectangle overlaps the given rectangle\n"
					+"\nEnter the coordinates for the center, height and width of the basic rectangle ",
					"Program description", JOptionPane.INFORMATION_MESSAGE);
			while (repeat) {
				try {
					//Taking as input center coordinates,height and width of basic rectangle
					double xc = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter x coordinate for the center of rectangle",
							"x-center", JOptionPane.QUESTION_MESSAGE));
					double yc = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter y coordinate for the center of rectangle",
							"y-center", JOptionPane.QUESTION_MESSAGE));
					double basicWidth = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter width of rectangle",
							"width", JOptionPane.QUESTION_MESSAGE));
					double basicHeight = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter height of rectangle",
							"height", JOptionPane.QUESTION_MESSAGE));
					C10E13MyRectangle2D basicRec = new C10E13MyRectangle2D(xc,  yc, basicWidth, basicHeight);
					
					boolean repeatValues = true;
					while (repeatValues) {
						//Displaying choices
						int option = Integer.parseInt(JOptionPane.showInputDialog(null,
								"1. Display area and perimeter of the given basic rectangle."+
						"\n2. Verify whether given point lies inside the basic rectangle."+
						"\n3. Verify whether a specified rectangle is inside the given basic rectangle."+
						"\n4. Verify whether a specified rectangle overlaps the given basic rectangle."+
						"\n\nSelect the option which needs to be executed.", "Select Choice",
								JOptionPane.QUESTION_MESSAGE));
						switch (option) {
						//Display area and perimeter of the given basic rectangle.
						case 1:
								JOptionPane.showMessageDialog(null, "Area and perimeter of the basic Rectanle, center ("+xc+", "+yc+") width "+basicWidth+", height "+basicHeight+" is: "+basicRec.getArea()+" and "+basicRec.getPerimeter()+" respectively.", "Result", JOptionPane.INFORMATION_MESSAGE);
								break;
						//Verify whether given point lies inside the basic rectangle
						case 2:
								JOptionPane.showMessageDialog(null,"Enter point x, y to test if it lies inside basic rectangle.","Input", JOptionPane.INFORMATION_MESSAGE);
								double xp = Double.parseDouble(JOptionPane.showInputDialog(null,"Enter x coordinate", "x", JOptionPane.QUESTION_MESSAGE));
								double yp = Double.parseDouble(JOptionPane.showInputDialog(null,"Enter y coordinate", "y", JOptionPane.QUESTION_MESSAGE));
								boolean check1 = basicRec.contains(xp, yp);
								if(check1)
									JOptionPane.showMessageDialog(null, "Point P("+xp+", "+yp+") lies inside the Basic Rectangle.", "Result", JOptionPane.INFORMATION_MESSAGE);
								else
									JOptionPane.showMessageDialog(null, "Point P("+xp+", "+yp+") does not lies inside the Basic Rectangle.", "Result", JOptionPane.INFORMATION_MESSAGE);
									
								break;
						//Verify whether a specified rectangle is inside the given basic rectangle.
						case 3:
								JOptionPane.showMessageDialog(null,"Enter the center coordinates x, y, width and height of the test Rectangle.","Rectangle Inside Rectangle?", JOptionPane.INFORMATION_MESSAGE);
								double x2 = Double.parseDouble(JOptionPane.showInputDialog(null,"Enter x coordinate for center of rectangle", 
											"x", JOptionPane.QUESTION_MESSAGE));
								double y2 = Double.parseDouble(JOptionPane.showInputDialog(null,"Enter y coordinate for center of rectangle", 
											"y", JOptionPane.QUESTION_MESSAGE));
								double Width2 = Double.parseDouble(JOptionPane.showInputDialog(null,"Enter width of rectangle", 
											"width", JOptionPane.QUESTION_MESSAGE));
								double Height2 = Double.parseDouble(JOptionPane.showInputDialog(null,"Enter height of rectangle", 
											"height", JOptionPane.QUESTION_MESSAGE));
								boolean check2 = basicRec.contains(new C10E13MyRectangle2D(x2, y2, Width2, Height2));
								if(check2)
									JOptionPane.showMessageDialog(null, "Rectanle with center ("+x2+", "+y2+") width "+Width2+", height "+Height2+
												" lies inside the Basic Rectangle.", "Result", JOptionPane.INFORMATION_MESSAGE);
								else
									JOptionPane.showMessageDialog(null, "Rectanle with center ("+x2+", "+y2+") width "+Width2+", height "+Height2+
												" does not lies inside the Basic Rectangle.", "Result", JOptionPane.INFORMATION_MESSAGE);
								break;
									
						//Verify whether a specified rectangle overlaps the given basic rectangle.
						case 4:
							JOptionPane.showMessageDialog(null,
										"Enter the center coordinates x, y, width and height of the Rectangle to test overlap condition.",
										"Rectangle Overlaps Rectangle?", JOptionPane.INFORMATION_MESSAGE);
							double x3 = Double.parseDouble(JOptionPane.showInputDialog(null,"Enter x coordinate for center of rectangle", 
										"x", JOptionPane.QUESTION_MESSAGE));
							double y3 = Double.parseDouble(JOptionPane.showInputDialog(null,"Enter y coordinate for center of rectangle", 
										"y", JOptionPane.QUESTION_MESSAGE));
							double Width3 = Double.parseDouble(JOptionPane.showInputDialog(null,"Enter width of rectangle", 
										"width", JOptionPane.QUESTION_MESSAGE));
							double Height3 = Double.parseDouble(JOptionPane.showInputDialog(null,"Enter height of rectangle", 
										"height", JOptionPane.QUESTION_MESSAGE));
								
							boolean check3 = basicRec.overlaps(new C10E13MyRectangle2D(x3, y3, Width3, Height3));
							if(check3)
								JOptionPane.showMessageDialog(null, 
											"Rectangle with center ("+x3+", "+y3+") width "+Width3+", height "+Height3+
											" overlaps the Basic Rectangle.", "Result", JOptionPane.INFORMATION_MESSAGE);
							else
								JOptionPane.showMessageDialog(null, 
											"Rectangle with center ("+x3+", "+y3+") width "+Width3+", height "+Height3+
											" does not overlap the Basic Rectangle.", "Result", JOptionPane.INFORMATION_MESSAGE);
								
							break;
						default: JOptionPane.showMessageDialog(null, "Please enter a valid choice number", "Error",JOptionPane.ERROR_MESSAGE);
							}//switch ends

						// Ask user if the program needs to be re-executed.
						int confirmInnerOption = JOptionPane.showConfirmDialog(null,
								"Do you want to test with different test points and rectangles? \nOR "
								+ "\nDo you want to repeat for another choice",
								"Repeat confirmation", JOptionPane.YES_NO_OPTION);
						if (confirmInnerOption == 0)
							repeatValues = true;
						else
							repeatValues = false;
					}//Inner while loop ends.
				} catch (Exception exception) {
					if(exception.getMessage()== null){
						JOptionPane.showMessageDialog(null,
								"Exception Occured. Please try again",
								"Exception", JOptionPane.ERROR_MESSAGE);
					}
					else{
						JOptionPane.showMessageDialog(null,
								exception.getMessage(),
								"Exception", JOptionPane.ERROR_MESSAGE);

					}
				}
				// Ask user if the program needs to be re-executed.
				int confirmOption = JOptionPane.showConfirmDialog(null,
						"Do you want to repeat the program with different basic Rectangle?",
						"Repeat confirmation", JOptionPane.YES_NO_OPTION);
				if (confirmOption == 0)
					repeat = true;
				else
					repeat = false;
			}//end of outer loop

		}//end of main
}
