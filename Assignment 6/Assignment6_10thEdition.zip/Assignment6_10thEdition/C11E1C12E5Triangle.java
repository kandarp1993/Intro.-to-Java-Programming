/**
 * Author - Kandarp Desai
 * CWID - 10419687
 * Date - 10/12/2017
 * Description - This program creates Triangle class, sets the value for its attributes, calculates area and perimeter
 * 				 of the triangle.   
 **/
public class C11E1C12E5Triangle extends GeometricObject{
	double side1,side2,side3 = 1;
	String message;
	
	public C11E1C12E5Triangle() throws Exception {
		setSide1(1);
		setSide2(1);
		setSide3(1);
	}
	public C11E1C12E5Triangle(double side1, double side2, double side3, String color, boolean filled) throws Exception{
		setSide1(side1);
		setSide2(side2);
		setSide3(side3);
		setColor(color);
		setFilled(filled);
	}

	public double getSide1() {
		return side1;
	}
	public void setSide1(double side1) throws Exception {
		if(isValidSide(side1)) {
			Exception e = new Exception(message);
        	throw e;	
		}
		this.side1 = side1;	
	}
	public double getSide2() {
		return side2;
	}
	public void setSide2(double side2) throws Exception {
		if(isValidSide(side2)) {
			Exception e = new Exception(message);
        	throw e;	
		}
		this.side2 = side2;
	}
	public double getSide3() {
		return side3;
	}
	public void setSide3(double side3) throws Exception {
		if(isValidSide(side3)) {
			Exception e = new Exception(message);
        	throw e;	
		}
		this.side3 = side3;
	}
	// This method checks if side of triangle is valid or not.
	boolean isValidSide(double side) throws Exception {
		
		if (side <= 0) {
			message = "Length of a side of triangle cannot be 0 or negative.";
			return true;
		} else
			return false;
	}
	// This method calculates and returns the area of the triangle.
	public double getArea() {
		double p = (getSide1() + getSide2() + getSide3()) / 2;
		return Math.sqrt(p * ((p - getSide1()) * (p - getSide2()) * (p - getSide3())));
	}

	// This method calculates and returns the perimeter of the triangle.
	public double getPerimeter() {
		return getSide1() + getSide2() + getSide3();
	}

	// This method returns the string description of the triangle.
	public String toString() {
		return "Triangle: side1 = " + getSide1() + " side2 = " + getSide2() +
				" side3 = " + getSide3();
	}

}
