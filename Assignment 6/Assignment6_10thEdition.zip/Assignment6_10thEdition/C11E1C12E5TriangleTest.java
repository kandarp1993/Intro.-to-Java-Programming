/**
 * Author - Kandarp Desai
 * CWID - 10419687
 * Date - 10/12/2017
 * Description - Program to display area, perimeter, color and boolean value for filled or not for a triangle using GeometricObject 
 * 				 class and IllegalTriangleException class.
 */

import javax.swing.JOptionPane;

public class C11E1C12E5TriangleTest {
	public static void main(String[] args) {
		boolean repeat = true;
		while (repeat) {
			try {
				JOptionPane.showMessageDialog(null, "This program displays the area, perimeter, color of the given triangle, "
						+ "\nand also indicate whether the triangle is filled or not.",
						"Program description", JOptionPane.INFORMATION_MESSAGE);
				String result = "";
				//Taking as input sides of triangle,color and boolean value for filled
				JOptionPane.showMessageDialog(null,"Enter three sides of the triangle,"
						+ " a color, and a boolean value to indicate whether the triangle is filled or not.",
								"Input", JOptionPane.QUESTION_MESSAGE);
				double side1 = Double.parseDouble(JOptionPane.showInputDialog(null,
						"Enter value for side 1 of the triangle", "side1", JOptionPane.QUESTION_MESSAGE));
				double side2 = Double.parseDouble(JOptionPane.showInputDialog(null,
						"Enter value for side 2 of the triangle", "side2", JOptionPane.QUESTION_MESSAGE));
				double side3 = Double.parseDouble(JOptionPane.showInputDialog(null,
						"Enter value for side 3 of the triangle", "side3", JOptionPane.QUESTION_MESSAGE));
				//Checking if two sides of triangle is greater than third side
				if(side1 + side2 <= side3 || side2 + side3 <= side1 || side1 + side3 <= side2) {
					//Throwing IllegalTriangleException if sum of two sides is less than third side
					IllegalTriangleException illegalTriangle = new IllegalTriangleException(
							"In a triangle, the sum of any two sides must be greater than the other side.");
					throw illegalTriangle;
				}
				String color = JOptionPane.showInputDialog(null,
						"Enter the color of the triangle", "color", JOptionPane.QUESTION_MESSAGE);
				if (color.isEmpty()) {
					Exception e = new Exception(
							"Incorrect input. Please enter a color for the triangle");
					throw e;
				}
				String fill = JOptionPane.showInputDialog(null,
						"Enter true or false to indicate whether triangle is filled or not", "fill", JOptionPane.QUESTION_MESSAGE);
				if (fill.isEmpty()) {
					Exception e = new Exception(
							"Incorrect input. Please enter true or false to indicate whether triangle is filled or not");
					throw e;
				}
				if (!fill.equals("true") && !fill.equals("false")) {
					Exception e = new Exception(
							"Incorrect input. Please enter true or false to indicate whether the triangle is filled.");
					throw e;
				}
				boolean filled = Boolean.parseBoolean(fill);
				//Declaring object
				C11E1C12E5Triangle triangle = new C11E1C12E5Triangle(side1, side2, side3, color, filled);
				result = triangle.toString()+"\n"
						+"Area of the triangle is: "+triangle.getArea()+" sq.units\n"
						+"Perimeter of the above triangle is: "+triangle.getPerimeter()+"\n"
						+"Color of the triangle: "+triangle.getColor()+"\n"
						+"Is Triangle filled? "+triangle.isFilled()+"\n";
				//Displaying output
				JOptionPane.showMessageDialog(null, result, "Result",
						JOptionPane.INFORMATION_MESSAGE);
			} catch (Exception e) {
				
				if(e.getMessage()== null){
					
					JOptionPane.showMessageDialog(null,
							"Exception occured.","Exception", JOptionPane.ERROR_MESSAGE);
				}
				else{
					JOptionPane.showMessageDialog(null,
							"Exception occured : " + e.getMessage()+"\nPlease retry with different input",
							"Exception", JOptionPane.ERROR_MESSAGE);

					}
				}
			// Ask user if the program needs to be re-executed.
			int confirm = JOptionPane.showConfirmDialog(null,
					"Do you want to repeat the program?",
					"Repeat confirmation", JOptionPane.YES_NO_OPTION);
			if (confirm == 0)
				repeat = true;
			else
				repeat = false;
		}//end of while loop

	}//end of main method
}
